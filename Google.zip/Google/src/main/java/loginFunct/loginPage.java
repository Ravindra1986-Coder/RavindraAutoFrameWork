package loginFunct;

public class loginPage {

}
